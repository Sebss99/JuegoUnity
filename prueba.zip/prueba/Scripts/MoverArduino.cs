﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO.Ports;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class MoverArduino : MonoBehaviour {

    //vidas
    public Vidas vida_Canvas;
    private int numeroVidas=3;
    public string escenaGameOver;

    //variables desde Arduino
    public SerialPort puerto = new SerialPort("COM3", 9600);
    int dato1;
    int dato2;
    int dato3;

    //Variables para Reaparecer
    public Transform target;
    public float velAparecer;
    bool paraAparecer=false;

    //variables de movimiento
    public float velocidad;
    public float distancia = 0;

    //Animaciones
    Animator animator;

    //Audio
    //public AudioClip pruebaAudio;
    //AudioSource fuenteAudio;
    


    // Use this for initialization
    void Start()
    {
        puerto.Open();
        puerto.ReadTimeout = 1;
        // cubito = GameObject.Find("cosa");
        PlayerPrefs.SetInt("cubo", 0);
        PlayerPrefs.SetInt("saltar", 0);
        //paMorir = GameObject.Find("Player");
        //fuenteAudio = GetComponent<AudioSource>();


    }

    // Update is called once per frame
    void Update()
    {
        if (puerto.IsOpen)
        {
            try
            {
                prueba(puerto.ReadLine());

                transform.Translate(Vector3.forward * velocidad, Space.Self);

                mover();
                salto();
                moverPlat();
                //Debug.Log(numeroVidas);
                vida_Canvas.CambioDeVida(numeroVidas);
                GameOver();
                //Debug.Log(paraAparecer);
                Reaparecer();

            }
            catch (System.Exception)
            {

            }
        }
    }


    private void Awake()
    {
        animator = GetComponent<Animator>();
    }

    public void prueba(string datoAr)
    {
        string[] datosArray = datoAr.Split(char.Parse(","));
        if (datosArray.Length == 3)
        {
            dato1 = int.Parse(datosArray[0]);
            dato2 = int.Parse(datosArray[1]);
            dato3 = int.Parse(datosArray[2]);
        }
    }




    public void mover()
    {

        if (dato3 > 320 && dato3 < 450)
        {
           // Debug.Log("centro");
        }


        if (dato3 < 310)
        {
            //Debug.Log("izquierda");
            transform.Translate(Vector3.left * distancia, Space.Self);
           

        }




        if (dato3 > 500)
        {
            //Debug.Log("derecha");
            transform.Translate(Vector3.right * distancia, Space.Self);
         
        }
    }


    public void salto()
    {
        if (dato1 == 1 && dato2 == 1)
        {
            PlayerPrefs.SetInt("saltar", 1);
            // Debug.Log("Salto");
            /*fuenteAudio.clip = pruebaAudio;
            fuenteAudio.Play();*/
        }
        else
        {
            PlayerPrefs.SetInt("saltar", 0);
        }

        bool salto = dato1 == 1 && dato2 == 1;
        animator.SetBool("salto", salto);
    }


    /*public static float map(float value, float leftMin, float leftMax, float rightMin, float rightMax)
    {
        return rightMin + (value - leftMin) * (rightMax - rightMin) / (leftMax - leftMin);
    }*/


    public void moverPlat()
    {


        if (dato1 == 0)
        {
            PlayerPrefs.SetInt("cubo", 0);

        }

        if (dato1 == 1)
        {
           // Debug.Log("Dato1");
            PlayerPrefs.SetInt("cubo", 1);

        }


        if (dato2 == 1)
        {
           // Debug.Log("Dato2");
            PlayerPrefs.SetInt("cubo", 2);
        }


    }


    private void OnTriggerEnter(Collider other)
    {
        if (other.tag=="Perder")
        {
            
            --numeroVidas;
            paraAparecer = true;
        }
    }

    public void GameOver()
    {
        if (numeroVidas <= 0)
        {
            Debug.Log("game over");
            SceneManager.LoadScene(escenaGameOver);
        }
    }


    public void Reaparecer()
    {
        if (paraAparecer == true)
        {
            paraAparecer = false;
            float step = velAparecer * Time.deltaTime;
            transform.position = Vector3.MoveTowards(transform.position, target.position, step);
        }
    }



}
