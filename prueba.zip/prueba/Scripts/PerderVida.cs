﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PerderVida : MoverArduino
{

    //public Vidas vida_Canvas;
    
   // GameObject muerte;

    // Use this for initialization
    void Start()
    {
        //muerte = GameObject.Find("Player");
    }


    /*private void OnTriggerEnter(Collider other)
    {
        if (other.tag == "Player")
        {
            --numeroVidas;

        }   
    }*/

    /*public void GameOver()
    {
        if (numeroVidas == 0)
        {
            Destroy(muerte, (float)1);
        }
    }*/

}
