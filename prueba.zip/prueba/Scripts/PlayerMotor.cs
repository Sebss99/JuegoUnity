﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMotor : MoverArduino {

    private CharacterController controller;

    private float verticalVelocity;
    private float gravity = 14.0f;
    public float jumpForce = 10.0f;
    public int recibir2;


    // Use this for initialization
    void Start () {
        controller = GetComponent<CharacterController>();
             
            
	}
	
	// Update is called once per frame
	void Update () {

        recibir2 = PlayerPrefs.GetInt("saltar", 0);

        if (controller.isGrounded)
        {
            verticalVelocity = -gravity * Time.deltaTime;
            if (recibir2==1)
            {
                verticalVelocity = jumpForce;
            }
        }
        else
        {
            verticalVelocity -= gravity * Time.deltaTime;
        }

        Vector3 moveVector = new Vector3(0,verticalVelocity,0);
        controller.Move(moveVector * Time.deltaTime);
	}
}
