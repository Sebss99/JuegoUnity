﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Vidas : MonoBehaviour {


    public Sprite[] corazones;
    
    

	// Use this for initialization
	void Start () {
        CambioDeVida(3);
	}
	
	// Update is called once per frame
	void Update () {
       
	}

    public void CambioDeVida(int pos)
    {
        this.GetComponent < Image >().sprite= corazones[pos];
    }
   
}
