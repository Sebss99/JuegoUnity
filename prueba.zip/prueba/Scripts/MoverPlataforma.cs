﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MoverPlataforma : MoverArduino {
    public int recibir;
    

    // Use this for initialization
    void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        recibir = PlayerPrefs.GetInt("cubo", 0);
        


        if (recibir == 0)
        {
            transform.Translate(Vector3.zero * 0, Space.Self);
        }

        if (recibir == 1)
        {
            transform.Translate(Vector3.down * distancia, Space.Self);
        }

        if (recibir == 2)
        {
            transform.Translate(Vector3.up * distancia, Space.Self);
        }

    }
}
