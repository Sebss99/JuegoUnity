﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MoverArduino {

    public float horizontalM;
    public float verticalM;
    public float speed;

    public float gravity = 9.8f;
    private Vector3 movePlayer;
    public CharacterController player;

        // Use this for initiaization
	void Start () {
        player = GetComponent<CharacterController>();
	}
	
	// Update is called once per frame
	void Update () {

        horizontalM = Input.GetAxis("Horizontal");
        verticalM = Input.GetAxis("Vertical");
        SetGravity();
		
	}

    private void FixedUpdate()
    {

        player.Move(new Vector3(horizontalM,0,verticalM)*speed*Time.deltaTime);

    }


    public void SetGravity()
    {
        movePlayer.y = -gravity * Time.deltaTime;
    }
}
